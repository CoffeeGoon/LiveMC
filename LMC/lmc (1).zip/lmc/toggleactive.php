<?php
$id = $_GET['user'];
$val = $_GET['value'];
$typ = $_GET['typ'];
$mysqli =  new mysqli("lmc.konghexdev.x10host.com" ,"konghexd_LMCuser" , "BoldPassword23" , "konghexd_LMC");
$tname = "band_account";
if($typ != "band" ){ $tname = "venue_account";}
$statement = "UPDATE " . $tname . " SET active= '" . $val . "' WHERE username = '" . $id . "' "; 
if($mysqli->query($statement)){
if($val == 'false'){
$statmentB = "SELECT username FROM venue_accounts";
$requestname ="venuerequests_";
if($typ == 'venue') { $statmentB = "SELECT username FROM band_accounts"; 
$requestname = "bandrequests_";
}
 $return = $mysqli->query($statmentB);
$row = $return->fetch_assoc();
while($row != 0){
$tablename = $requestname . $row['username'];
$qst = "DELETE  FROM " . $tablename . " WHERE username='" . $id . "' ";
$mysqli->query($qst);
$row = $return->fetch_assoc(); 
}

}
}
echo $_GET['callback'] . "( { 'good' : 'done' } )" ;
?>