<?php
$mysqli =  new mysqli("lmc.konghexdev.x10host.com" ,"konghexd_LMCuser" , "BoldPassword23" , "konghexd_LMC");
$args = array(7);
$args[0] = htmlentities($_GET['use']);
$args[1] =htmlentities( $_GET['password']);
$args[2] =htmlentities( $_GET['name']);
$args[3] = htmlentities( $_GET['contact']);
$args[4] = htmlentities( $_GET['abio']);
$success = false;
 if($_GET['type'] == 'band'){
  $breq = "bandrequests_" . $args[0];
  $q1 = "INSERT INTO band_account (username, password, name, contact_info, active, band_requests_id, band_bio) VALUES ( '" . $args[0] . "' , '" . $args[1] . "' ,'" . $args[2] . "' , '" . $args[3] . "' , 'false' , '" . $breq . "' , '" . $args[4] . "')";
 if( $mysqli->query( $q1)){ $success = true; }
 if($success){ 

if(! $mysqli->query("INSERT INTO band_accounts (username, password) VALUES ('" . $args[0] . "', '" . $args[1] . "')")){ $success = false; }
}
if($success){
 if( ! $mysqli->query("CREATE TABLE $breq(username varchar(40), descript varchar(60))")){ $success = false; }
}
if(! $success ) { echo $_GET['callback'] . "(" . "{ 'return' : 'no'  }" . ")"; }
}
else{
$breq = "venuerequests_" . $args[0];
 $q1 ="INSERT INTO venue_account (username, password, name, contact_info, active, venue_requests_id, venue_bio) VALUES ( '" . $args[0] . "' , '" . $args[1] . "' ,'" . $args[2] . "' , '" . $args[3] . "' , 'false' , '" . $breq . "' , '" . $args[4] . "')";
 if( $mysqli->query( $q1) ){ $success = true; }
 if($success){
 if( ! $mysqli->query("INSERT INTO venue_accounts (username, password) VALUES ('" . $args[0] . "', '" . $args[1] . "')")){$success = false; }
 
}
if($success){
 if(! $mysqli->query("CREATE TABLE $breq(username varchar(40), descript varchar(60))") ) {$success = false; }
}
if(! $success) { echo $_GET['callback'] . "(" . "{ 'return' : 'no'  }" . ")"; }
}

//echo $q1 . " ";
if($success) {
echo $_GET['callback'] . "(" . "{ 'return' : 'yes'  }" . ")";
}
?>