<?php
$mysqli =  new mysqli("lmc.konghexdev.x10host.com" ,"konghexd_LMCuser" , "BoldPassword23" , "konghexd_LMC");
$reqid = $_GET['user'];
$actf = $_GET['otheruser'];
$type = $_GET['type'];
$del = false;
$tname = '';
if($type == 'band'){
$retval = $mysqli->query("SELECT band_requests_id FROM band_account where username='" . $reqid . "'");
$assoc = $retval->fetch_assoc();
if($assoc){
	$del = true;
  $tname = $assoc['band_requests_id'];
}
}

if($type == "venue"){
$retval = $mysqli->query("SELECT venue_requests_id FROM  venue_account where username='" . $reqid . "'");
$assoc = $retval->fetch_assoc();
if($assoc){
	$del = true;
  $tname = $assoc['venue_requests_id'];
}
}
if($del){
$querystring = "DELETE  FROM " . $tname . " WHERE descript='" . $actf . "'";
$mysqli->query($querystring);
echo $_GET['callback'] . "(" . "{'zoom' : 'worked' }" . ")";
}
else{
echo $_GET['callback'] . "(" . "{'zoom' : '" .  $actf  . "' }" . ")";
}
?>